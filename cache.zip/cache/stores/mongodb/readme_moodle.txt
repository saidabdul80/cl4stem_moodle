MongoDB PHP
-----------
Download from https://github.com/mongodb/mongo-php-library/releases

Import procedure:

- Copy all the files and folders from the folder mongodb/src in the cache/stores/mongodb/MongoDB directory.
- Copy the license file from the project root.
- Update thirdpartylibs.xml with the latest version.
- Check the minim php driver version in https://docs.mongodb.com/drivers/php#compatibility and change the value in the "are_requirements_met" method if necessary.

This version (1.8.0) requires PHP mongodb extension >= 1.8.0
